using System;
using Unity.Entities;
using UnityEngine;

public class Gui : MonoBehaviour {
    public const int GemsLayer = 8;
    public const int CellsLayer = 9;
    public static Gui Instance { get; private set; }
    [SerializeField] public GridView GridView;
    [SerializeField] public Camera Camera;

    private void Start() {
        Instance = this;
        Camera.transform.position = new Vector3(GridView.GridSize.x / 2.0f, 55, GridView.GridSize.y / 2.0f);
        Camera.orthographicSize = Math.Max(GridView.GridSize.x / 2.0f, GridView.GridSize.y / 2.0f) + 1;
    }

    public void onCheckGrid() {
        var em = World.DefaultGameObjectInjectionWorld.EntityManager;
        em.AddComponent<GridStepMoveTag>(GridView.GridEntity);
        em.AddComponent<GridCheckMatchTag>(GridView.GridEntity);
    }
}
