using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Unity.Entities;
using Unity.Rendering;

public class CellCreator : MonoBehaviour, IConvertGameObjectToEntity, IDeclareReferencedPrefabs {
    public GameObject cellPrefab;
    public GameObject gemPrefab;
    public List<Material> gemMaterials;
    public List<Material> cellsMaterials;
    public List<GameObject> bonusPrefabs;
    public Material selectedCellMaterial;
    
    public static Entity CellPrefabEntity;
    public static Entity GemPrefabEntity;
    public static List<Entity> BonusEntities; // TODO: really need?
    public static List<RenderMesh> GemRMs;
    public static List<RenderMesh> CellRMs;
    public static List<RenderMesh> BonusRms;
    public static RenderMesh SelectedRM;
    
    
    public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem) {
        CellPrefabEntity = conversionSystem.GetPrimaryEntity(cellPrefab);
        GemPrefabEntity = conversionSystem.GetPrimaryEntity(gemPrefab);
        BonusEntities = bonusPrefabs.Select(conversionSystem.GetPrimaryEntity).ToList(); 
        
        var gemRM = dstManager.GetSharedComponentData<RenderMesh>(GemPrefabEntity);
        GemRMs = gemMaterials.Select(t => new RenderMesh {
            mesh = gemRM.mesh,
            material = t
        }).ToList();

        var cellRM = dstManager.GetSharedComponentData<RenderMesh>(CellPrefabEntity);
        CellRMs = cellsMaterials.Select(t => new RenderMesh {
            mesh = cellRM.mesh,
            material = t
        }).ToList();

        BonusRms = BonusEntities.Select(dstManager.GetSharedComponentData<RenderMesh>).ToList();

        SelectedRM = new RenderMesh {
            mesh = cellRM.mesh,
            material = selectedCellMaterial
        };
        
        dstManager.DestroyEntity(entity);
    }

    public void DeclareReferencedPrefabs(List<GameObject> referencedPrefabs) {
        referencedPrefabs.Add(cellPrefab);
        referencedPrefabs.Add(gemPrefab);
        referencedPrefabs.AddRange(bonusPrefabs);
    }
}