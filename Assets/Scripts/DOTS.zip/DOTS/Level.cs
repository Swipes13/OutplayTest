using System;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;

[Serializable]
public class Level {
    public int2 s;
    public List<GemData> g;
    public List<CellData> c;

    public List<int2> bc;
    public List<int2> ec;

    public static Level FromJson(string json) {
        var myObject = JsonUtility.FromJson<Level>(json);
        myObject.InitAfterLoadFromJson();
        return myObject;
    }

    private int GetIndex(int x, int y) {
        return x + y * s.x;
    }

    private void InitAfterLoadFromJson() {
        if (c == null || c.Count == 0) {
            c = new List<CellData>(new CellData[s.x * s.y]);
            for (var y = 0; y < s.y; y++) {
                for (var x = 0; x < s.x; x++) {
                    var index = GetIndex(x, y);
                    var cd = new CellData {
                        Index = index,
                        Pos = new int2(x, y),
                        Type = CellType.Empty
                    };
                    if (bc != null && bc.Contains(cd.Pos)) cd.Type = CellType.Blocked;
                    c[index] = cd;
                }
            }
        }

        if (g == null || g.Count == 0) {
            g = new List<GemData>(new GemData[s.x * s.y]);
            
            for (var y = 0; y < s.y; y++) {
                for (var x = 0; x < s.x; x++) {
                    var index = GetIndex(x, y);
                    var leaveEmpty = true; // ec != null && ec.Contains(new int2(x, y));
                    var gt = GemType.Empty;
                    
                    if (c[index].Type == CellType.Blocked) gt = GemType.Blocked;
                    else if (!leaveEmpty) gt = GridView.GetRandomGemType(); 
                    
                    var gd = new GemData {
                        Index = index,
                        Pos = new int2(x, y),
                        Type = gt,
                        CellEntity = Entity.Null
                    };
                    g[index] = gd;
                }
            }
        }
    }
}
