using Unity.Entities;
using Unity.Mathematics;

public enum CellType {
    Empty = 0,
    Blocked
}

public enum GemType {
    Empty = 0,
    Blocked = 1,
    Red = 2,
    Blue = 3,
    Green = 4,
    
    Bomb1,
}

// GRID DATA
public struct CreateGridTag : IComponentData {}
public struct GridCheckMatchTag : IComponentData {}
public struct GridStepMoveTag : IComponentData {}
public struct GridCheckCanMoveTag : IComponentData {}
public struct GridReshuffleTag : IComponentData {}

[GenerateAuthoringComponent]
public struct GridData : IComponentData {
    public int2 Size;
}

public struct PossibleMove {
    public int2 SwapElements; 
    public int2 Force;
}

// CELL DATA
public struct CellInvalidateRenderTag : IComponentData {}

// [InternalBufferCapacity(100)]
// public struct CellBE : IBufferElementData {
//     public Entity Cell;
// }
public struct CellData : IComponentData {
    public int Index;
    public int2 Pos;
    public CellType Type;
    public bool Selected;
}

// GEM DATA
public struct GemInvalidateRenderTag : IComponentData {}

// [InternalBufferCapacity(100)]
// public struct GemBE : IBufferElementData {
//     public Entity Gem;
// }
public struct GemData : IComponentData {
    public int Index;
    public int2 Pos;
    public GemType Type;
    public bool NeedToRemove;
    public Entity CellEntity;

    public bool Checked;
}

public struct GemMoveData : IComponentData {
    public float Time;
    public float PosSpeed;
    public float3 PosVec;
}

public struct GemSwapData : IComponentData {
    public float FullTime;
    public float Time;
    public float3 PosFrom;
    public float3 PosTo;
    // public bool WithBack;
    public bool Up;
}

public struct GemRemoveData : IComponentData {
    public float3 PosTo;
    public float ScaleTo;
    public float Time;

    public float ScaleSpeed;
    public float PosSpeed;
    public float3 PosVec;
}

public struct GemSelectedTag : IComponentData {}