using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;

[UpdateAfter(typeof(GridCheckMatchSystem))]
public class GemInvalidateRenderSystem : ComponentSystem {
    protected override void OnUpdate() {
        Entities.WithAll<GemInvalidateRenderTag>().ForEach((Entity entity, ref GemData gemData) => {
            if (gemData.Type < GemType.Bomb1) {
                PostUpdateCommands.SetSharedComponent(entity, CellCreator.GemRMs[(int)gemData.Type]);    
            } else {
                // var bonus = gemData.Type >= GemType.Bomb1;
                var t = (int)gemData.Type - (int)GemType.Bomb1;
                PostUpdateCommands.SetSharedComponent(entity, CellCreator.BonusRms[t]);
            }
            PostUpdateCommands.RemoveComponent<GemInvalidateRenderTag>(entity);
        });
    }
}

[UpdateAfter(typeof(GridCheckMatchSystem))]
public class GemRemoveSystem : SystemBase {
    private EntityQuery m_query;
    protected override void OnCreate() {
        var queryDescription = new EntityQueryDesc {
            All = new[] {
                ComponentType.ReadWrite<Translation>(),
                ComponentType.ReadWrite<Scale>(),
                ComponentType.ReadWrite<GemRemoveData>(),
            }
        };
        m_query = GetEntityQuery(queryDescription);
    }
    protected override void OnUpdate() {
        var ecb = new EntityCommandBuffer(Allocator.TempJob);
        
        var job = new GemRemoveChunkJob {
            Delta = Time.DeltaTime,
            TranslationType = GetArchetypeChunkComponentType<Translation>(),
            ScaleType = GetArchetypeChunkComponentType<Scale>(),
            GemRemoveType = GetArchetypeChunkComponentType<GemRemoveData>(),
            EntityType = GetArchetypeChunkEntityType(),
            Ecb = ecb.ToConcurrent()
        };
        Dependency = job.ScheduleParallel(m_query, Dependency);
        Dependency.Complete();
        
        ecb.Playback(EntityManager);
        ecb.Dispose();
    }

    private struct GemRemoveChunkJob : IJobChunk {
        public float Delta;
        public ArchetypeChunkComponentType<Translation> TranslationType;
        public ArchetypeChunkComponentType<Scale> ScaleType;
        public ArchetypeChunkComponentType<GemRemoveData> GemRemoveType;
        [ReadOnly] public ArchetypeChunkEntityType EntityType;

        public EntityCommandBuffer.Concurrent Ecb;

        public void Execute(ArchetypeChunk chunk, int chunkIndex, int firstEntityIndex) {
            var translations = chunk.GetNativeArray(TranslationType);
            var scales = chunk.GetNativeArray(ScaleType);
            var gemRemoves = chunk.GetNativeArray(GemRemoveType);
            var ents = chunk.GetNativeArray(EntityType);

            for (var i = 0; i < chunk.Count; i++) {
                var translation = translations[i];
                var scale = scales[i];
                var removeData = gemRemoves[i];
                
                removeData.Time -= Delta;
                scale.Value -= Delta * removeData.ScaleSpeed;
                translation.Value -= Delta * removeData.PosVec * removeData.PosSpeed;

                if (removeData.Time < 0) {
                    Ecb.DestroyEntity(chunkIndex * chunk.Count + i, ents[i]);
                } else {
                    translations[i] = translation;
                    scales[i] = scale;
                    gemRemoves[i] = removeData;
                }
            }
        }
    }
}

[UpdateAfter(typeof(GridCheckMatchSystem))]
public class GemMoveSystem : SystemBase {
    private EntityQuery m_query;
    protected override void OnCreate() {
        var queryDescription = new EntityQueryDesc {
            All = new[] {
                ComponentType.ReadWrite<Translation>(),
                ComponentType.ReadWrite<GemMoveData>(),
                ComponentType.ReadOnly<GemData>(),
            }
        };
        m_query = GetEntityQuery(queryDescription);
    }
    protected override void OnUpdate() {
        var ecb = new EntityCommandBuffer(Allocator.TempJob);
        
        var job = new GemMoveChunkJob {
            Delta = Time.DeltaTime,
            TranslationType = GetArchetypeChunkComponentType<Translation>(),
            GemMoveType = GetArchetypeChunkComponentType<GemMoveData>(),
            GemDataType = GetArchetypeChunkComponentType<GemData>(true),
            EntityType = GetArchetypeChunkEntityType(),
            Ecb = ecb.ToConcurrent()
        };
        Dependency = job.ScheduleParallel(m_query, Dependency);
        Dependency.Complete();
        
        ecb.Playback(EntityManager);
        ecb.Dispose();
    }

    private struct GemMoveChunkJob : IJobChunk {
        public float Delta;
        public ArchetypeChunkComponentType<Translation> TranslationType;
        public ArchetypeChunkComponentType<GemMoveData> GemMoveType;
        [ReadOnly] public ArchetypeChunkComponentType<GemData> GemDataType;
        [ReadOnly] public ArchetypeChunkEntityType EntityType;

        public EntityCommandBuffer.Concurrent Ecb;

        public void Execute(ArchetypeChunk chunk, int chunkIndex, int firstEntityIndex) {
            var translations = chunk.GetNativeArray(TranslationType);
            var gemMoves = chunk.GetNativeArray(GemMoveType);
            var gemDatas = chunk.GetNativeArray(GemDataType);
            var ents = chunk.GetNativeArray(EntityType);

            for (var i = 0; i < chunk.Count; i++) {
                var translation = translations[i];
                var moveData = gemMoves[i];
                var gemData = gemDatas[i];
                
                moveData.Time -= Delta;
                if (moveData.Time < 0) {
                    translation.Value = new float3(gemData.Pos.x, -1f, gemData.Pos.y);
                    translations[i] = translation;
                    Ecb.RemoveComponent<GemMoveData>(chunkIndex * chunk.Count + i, ents[i]);
                } else {
                    translation.Value -= Delta * moveData.PosVec * moveData.PosSpeed;
                    translations[i] = translation;
                    gemMoves[i] = moveData;
                }
            }
        }
    }
}


public class GemSwapSystem : ComponentSystem {
    protected override void OnUpdate() {
        var time = Time.DeltaTime;
        Entities.WithAll<GemSwapData>().ForEach((Entity entity, ref Translation translation, ref GemData gemData, ref GemSwapData swapData) => {
            swapData.Time -= time;
            if (swapData.Time >= 0) { 
                var a = swapData.Time / swapData.FullTime;
                translation.Value = new float3(
                    math.lerp(swapData.PosTo.x, swapData.PosFrom.x, a),
                    math.lerp(-1.0f, swapData.Up ? 1.0f : -1.0f, a * 2.0f),
                    math.lerp(swapData.PosTo.z, swapData.PosFrom.z, a)
                );
            } else { 
                if (swapData.Time >= -swapData.FullTime) {  
                    var a = -swapData.Time / swapData.FullTime;
                    translation.Value = new float3(
                        math.lerp(swapData.PosTo.x, swapData.PosFrom.x, a),
                        math.lerp(-1.0f, swapData.Up ? 1.0f : -1.0f, a * 2.0f),
                        math.lerp(swapData.PosTo.z, swapData.PosFrom.z, a)
                    );
                } else { 
                    translation.Value = swapData.PosFrom;
                    PostUpdateCommands.RemoveComponent<GemSwapData>(entity);
                    RemoveCellSelection(gemData);
                }
            }
        });
    }

    private void RemoveCellSelection(GemData gemData) {
        var cd = EntityManager.GetComponentData<CellData>(gemData.CellEntity);
        cd.Selected = false;
        EntityManager.SetComponentData(gemData.CellEntity, cd);
        EntityManager.AddComponent<CellInvalidateRenderTag>(gemData.CellEntity);
    }

}