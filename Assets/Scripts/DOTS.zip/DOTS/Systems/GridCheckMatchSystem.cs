using System.Collections.Generic;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Random = Unity.Mathematics.Random;

public class GridCheckMatchSystem : ComponentSystem {
    private Random viewRandom;
    protected override void OnCreate() {
        viewRandom = new Random(123);
        movingGroup = GetEntityQuery(typeof(GemMoveData));
        gridQuery = GetEntityQuery(typeof(GridCheckMatchTag));
    }
    private EntityQuery movingGroup;
    private EntityQuery gridQuery;
    
    private int MovingGemsCount() {
        var movingEntities = movingGroup.ToEntityArray(Allocator.TempJob);
        var count = movingEntities.Length;
        movingEntities.Dispose();
        return count;
    }

    protected override void OnUpdate() {
        var gridSize = GridView.Instance.GridSize;
        var random = GridView.Instance.Random;
        Entities.WithNone<GridStepMoveTag>().WithAll<GridCheckMatchTag>().ForEach((Entity grid, ref GridData gridData) => {
            if (MovingGemsCount() != 0) return;
            var entities = GridView.Instance.gems;
            var gems = new NativeArray<GemData>(gridSize.x * gridSize.y, Allocator.TempJob);
            var translations = new NativeArray<Translation>(gridSize.x * gridSize.y, Allocator.TempJob);
            
            Entities.WithAll<GemData>().ForEach((Entity entity, ref GemData gemData, ref Translation translation) => {
                gemData.Checked = false;
                gems[gemData.Index] = gemData;
                translations[gemData.Index] = translation;
            });

            new CheckMatchParallelJob {
                GridSize = gridSize, 
                Gems = gems
            }.Schedule(gems.Length, 32).Complete();

            var wasMatch = false;
            
            for (var i = 0; i < gems.Length; i++) {
                if (gems[i].NeedToRemove == false) continue;
                wasMatch = true;
                break;
            }
            
            if (wasMatch) {
                var ecb = new EntityCommandBuffer(Allocator.TempJob);
                var jh = new CreateDummiesJob {
                    Gems = gems,
                    Random = viewRandom,
                    Translations = translations,
                    Ecb = ecb.ToConcurrent()
                }.Schedule(gems.Length, 32);
                jh.Complete();
                
                ecb.Playback(EntityManager);
                ecb.Dispose();

                var neigs = new NativeArray<int>(4, Allocator.TempJob) { [0] = -1, [1] = 1, [2] = -gridSize.x, [3] = gridSize.x };
                var matched = new NativeList<int>(Allocator.TempJob);
                for (var i = 0; i < gems.Length; i++) {
                    if (!gems[i].NeedToRemove) continue;
                
                    matched.Clear();
                    CheckSameType(i, gems, neigs, ref matched);
                    if (matched.Length >= 4) { // GENERATE BONUS
                        var r = matched[random.NextInt(matched.Length)];
                        var gbomb = gems[r];
                        gbomb.Type = GemType.Bomb1;
                        gbomb.NeedToRemove = false;
                        gems[r] = gbomb;
                        if (r != i) {
                            EntityManager.SetComponentData(entities[r], gbomb);
                            EntityManager.AddComponent<GemInvalidateRenderTag>(entities[r]);
                        }
                    }

                    var g = gems[i];
                    if (g.NeedToRemove) { // Bomb that generated before!
                        g.Type = GemType.Empty;
                        g.NeedToRemove = false;
                        gems[i] = g;
                    }
                    
                    EntityManager.SetComponentData(entities[i], g);
                    EntityManager.AddComponent<GemInvalidateRenderTag>(entities[i]);
                }

                matched.Dispose();
                neigs.Dispose();
                
                
                
                PostUpdateCommands.AddComponent<GridStepMoveTag>(grid);
            } else {
                PostUpdateCommands.RemoveComponent<GridCheckMatchTag>(grid);
                PostUpdateCommands.AddComponent<GridCheckCanMoveTag>(grid);
            }
            gems.Dispose();
            translations.Dispose();
        });
    }

    private void CheckSameType(int index, NativeArray<GemData> gems, NativeArray<int> neighs, ref NativeList<int> matched) {
        var gem = gems[index];
        if (gem.Checked || gem.Type == GemType.Blocked || gem.Type == GemType.Empty) return;

        gem.Checked = true;
        gems[index] = gem; 

        matched.Add(index);

        for (var i = 0; i < neighs.Length; i++) {
            var nextIndex = index + neighs[i];
            if (i <= 1 && !GridView.CheckInGridLineH(nextIndex, index)) continue;
            if (i >= 2 && !GridView.CheckInGridLineV(nextIndex, index)) continue;

            var next = gems[nextIndex];
            if (next.NeedToRemove && next.Type == gem.Type) {
                CheckSameType(nextIndex, gems, neighs, ref matched);
            }
        }
    }
    private struct CreateDummiesJob : IJobParallelFor {
        [ReadOnly] public NativeArray<GemData> Gems;
        [ReadOnly] public NativeArray<Translation> Translations;
        public EntityCommandBuffer.Concurrent Ecb;
        public Random Random;
        
        public void Execute(int i) {
            if (!Gems[i].NeedToRemove) return;
                     
            var e = Ecb.Instantiate(i, CellCreator.GemPrefabEntity);
            var et = Translations[i];
            var scaleTo = 0.0f;//m_random.NextFloat(0.5f, 0.8f);
            var time = Random.NextFloat(0.5f, 0.8f);
            var posTo = new float3(
                et.Value.x + Random.NextFloat(-0.5f, 0.5f), 
                et.Value.y + Random.NextFloat(5f, 10f),
                et.Value.z + Random.NextFloat(-0.5f, 0.5f)
            );
            // et.Value.x,// + m_random.NextFloat(-2f, 2f), 
            // et.Value.y + 5f,//m_random.NextFloat(5f, 7f),
            // et.Value.z - m_random.NextFloat(2f, 3f) // + m_random.NextFloat(-2f, 2f)
            Ecb.AddComponent(i, e, new Scale { Value = 0.75f });
            
            Ecb.AddComponent(i, e, new GemRemoveData {
                PosTo = posTo,
                ScaleTo = scaleTo,
                Time = time, 
                ScaleSpeed = (0.75f - scaleTo) / time,
                PosSpeed = math.distance(et.Value, posTo) / time,
                PosVec = et.Value - posTo 
            });
            Ecb.SetComponent(i, e, new Translation { Value = et.Value });
                     
            var g = Gems[i]; 
            Ecb.SetSharedComponent(i, e, CellCreator.GemRMs[(int)g.Type]);
        }
    }

    private struct CheckMatchParallelJob : IJobParallelFor {
        public int2 GridSize;
        [NativeDisableContainerSafetyRestriction]
        public NativeArray<GemData> Gems;
        
        public void Execute(int i) {
            var accum = new NativeArray<int>(4, Allocator.Temp) {[0] = 0, [1] = 0, [2] = 0, [3] = 0};
            var neighbourOffsetArray = new NativeArray<int>(4, Allocator.Temp) {[0] = -1, [1] = 1, [2] = -GridSize.x, [3] = GridSize.x};
            
            var gem = Gems[i];

            if (gem.Type != GemType.Blocked && gem.Type != GemType.Empty && gem.NeedToRemove == false) {
                for (var j = 0; j < neighbourOffsetArray.Length; j++) {
                    var acc = 1;

                    while (true) { 
                        var gem2Index = gem.Index + neighbourOffsetArray[j] * acc;

                        if (j < 2) {
                            if (!CheckInGridLineH(gem2Index, gem.Index, Gems.Length, GridSize.x)) break;
                        } else {
                            if (!CheckInGridLineV(gem2Index, gem.Index, Gems.Length, GridSize.x)) break;
                        }
                        if (Gems[gem2Index].Type != gem.Type) break;
                        acc += 1;
                    }

                    accum[j] = acc - 1;
                }

                if (accum[0] + accum[1] + 1 >= 3 || accum[2] + accum[3] + 1 >= 3) {
                    gem.NeedToRemove = true;
                    Gems[i] = gem;
                }
            }

            neighbourOffsetArray.Dispose();
            accum.Dispose();
        }
        
        private bool CheckInGridLineH(int checkIndex, int compareIndex, int count, int line) {
            return checkIndex >= 0 && checkIndex < count && checkIndex / line == compareIndex / line;
        }
        private bool CheckInGridLineV(int checkIndex, int compareIndex, int count, int line) {
            return checkIndex >= 0 && checkIndex < count && checkIndex % line == compareIndex % line;
        }
    }
}
