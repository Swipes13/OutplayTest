
using Unity.Entities;
using Unity.Rendering;
using UnityEngine;

public class CellInvalidateRenderSystem : ComponentSystem {
    protected override void OnUpdate() {
        Entities.WithAll<CellInvalidateRenderTag>().ForEach((Entity entity, ref CellData cellData) => {
            if (cellData.Selected) {
                PostUpdateCommands.SetSharedComponent(entity, CellCreator.SelectedRM);
            } else {
                PostUpdateCommands.SetSharedComponent(entity, CellCreator.CellRMs[(int) cellData.Type]);
            }

            EntityManager.RemoveComponent<CellInvalidateRenderTag>(entity);
        });
    }
}