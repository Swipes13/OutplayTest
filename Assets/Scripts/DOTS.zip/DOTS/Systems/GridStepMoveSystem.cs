using System;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using Random = Unity.Mathematics.Random;

public class GridStepMoveSystem : ComponentSystem {
    private EntityQuery movingGroup;
    private EntityQuery gridQuery;
    
    protected override void OnCreate() {
        movingGroup = GetEntityQuery(typeof(GemMoveData));
        gridQuery = GetEntityQuery(typeof(GridCheckMatchTag));
    }
    
    private int MovingGemsCount() {
        var movingEntities = movingGroup.ToEntityArray(Allocator.TempJob);
        var count = movingEntities.Length;
        movingEntities.Dispose();
        return count;
    }
    
    protected override void OnUpdate() {
        Entities
            .WithAll<GridStepMoveTag>()
            .ForEach((Entity grid, ref GridData gridData) => {
                if (MovingGemsCount() > 0) return;
                
                var random = GridView.Instance.Random;
                var gridSize = gridData.Size;
                
                var gems = new NativeArray<GemData>(gridSize.x * gridSize.y, Allocator.TempJob);
                var entities = GridView.Instance.gems; 
                Entities.WithAll<GemData>().ForEach((Entity entity, ref GemData gemData) => gems[gemData.Index] = gemData);

                const float gemSpeed = 1.0f;
                var wasSwap = MoveNonStableGems(gridSize, gems, entities, gemSpeed, random);
                var wasEmpties = CreateEmpties(gridSize, gems, entities, gemSpeed);
                if (wasSwap == false && wasEmpties == false) EntityManager.RemoveComponent<GridStepMoveTag>(grid);
                
                gems.Dispose();
            });
    }

    private bool MoveNonStableGems(int2 gridSize, NativeArray<GemData> gems, NativeArray<Entity> entities, float gemSpeed, Random random) {
        var wasSwap = false;
        
        var randomLine = new NativeArray<int>(gridSize.x, Allocator.TempJob);
        for (var x = 0; x < gridSize.x; x++) randomLine[x] = x;
        var n = randomLine.Length;
        while (n > 0) {
            var k = random.NextInt(n--);
            var temp = randomLine[n];
            randomLine[n] = randomLine[k];
            randomLine[k] = temp;
        }
        
        for (var y = 1; y < gridSize.y; y++) {
            for (var inR = 0; inR < gridSize.x; inR++) {
                var x = randomLine[inR];
                var index = GridView.GetIndex(x, y);
                var gt = gems[index].Type;
                
                if (gt == GemType.Empty || gt == GemType.Blocked) continue;

                var downIndex = GridView.GetIndex(x, y - 1);
                if (gems[downIndex].Type == GemType.Empty) { 
                    SwapGems(index, downIndex, gems, entities, gemSpeed, EntityManager);
                    wasSwap = true;
                    continue;
                }
                
                // TODO: nice code? or left like that?
                if (random.NextBool()) {
                    if (x > 0) { 
                        var swapIndex = GridView.GetIndex(x - 1, y - 1);
                        if (gems[swapIndex].Type == GemType.Empty) { 
                            var nt = gems[GridView.GetIndex(x - 1, y)].Type;
                            if (nt == GemType.Empty || nt == GemType.Blocked) {
                                SwapGems(index, swapIndex, gems, entities, gemSpeed, EntityManager);
                                wasSwap = true;
                                continue;
                            } 
                        }
                    }
                    if (x < gridSize.x - 1) {
                        var swapIndex = GridView.GetIndex(x + 1, y - 1);
                        if (gems[swapIndex].Type == GemType.Empty) { 
                            var nt = gems[GridView.GetIndex(x + 1, y)].Type;
                            if (nt == GemType.Empty || nt == GemType.Blocked) {
                                SwapGems(index, swapIndex, gems, entities, gemSpeed, EntityManager);
                                wasSwap = true;
                                continue;
                            }
                        }
                    }    
                } else {
                    if (x < gridSize.x - 1) {
                        var swapIndex = GridView.GetIndex(x + 1, y - 1);
                        if (gems[swapIndex].Type == GemType.Empty) { 
                            var nt = gems[GridView.GetIndex(x + 1, y)].Type;
                            if (nt == GemType.Empty || nt == GemType.Blocked) {
                                SwapGems(index, swapIndex, gems, entities, gemSpeed, EntityManager);
                                wasSwap = true;
                                continue;
                            }
                        }
                    }
                    if (x > 0) { 
                        var swapIndex = GridView.GetIndex(x - 1, y - 1);
                        if (gems[swapIndex].Type == GemType.Empty) { 
                            var nt = gems[GridView.GetIndex(x - 1, y)].Type;
                            if (nt == GemType.Empty || nt == GemType.Blocked) {
                                SwapGems(index, swapIndex, gems, entities, gemSpeed, EntityManager);
                                wasSwap = true;
                            } 
                        }
                    }
                }
                
            }
        }

        randomLine.Dispose();
        return wasSwap;
    }

    private bool CreateEmpties(int2 gridSize, NativeArray<GemData> gems, NativeArray<Entity> entities, float gemSpeed) {
        var wasCreate = false;
        for (var x = 0; x < gridSize.x; x++) {
            var index = GridView.GetIndex(x, gridSize.y - 1);
            var gem = gems[index];
            if (gem.Type == GemType.Empty) {
                gem.Type = GridView.GetRandomGemType();
                gems[index] = gem;
                
                var gemEntity = entities[index];
                EntityManager.SetComponentData(gemEntity, gem);
                EntityManager.SetComponentData(gemEntity, new Translation { Value = new float3(gem.Pos.x, -1.0f, gem.Pos.y + 1) });
                EntityManager.AddComponent<GemInvalidateRenderTag>(gemEntity);
                
                EntityManager.AddComponentData(gemEntity, new GemMoveData {
                    PosVec = math.normalizesafe(new float3(0.0f, 0.0f, 1.0f)),
                    PosSpeed = gemSpeed,
                    Time = 1.0f / gemSpeed
                });
                wasCreate = true;
            }
        }

        return wasCreate;
    }

    public static void SwapGems(int index1, int index2, NativeArray<GemData> gems, NativeArray<Entity> entities, float gemSpeed, EntityManager entityManager) {
        var gem1 = gems[index1]; var gem2 = gems[index2];
        var gem1Entity = entities[index1]; var gem2Entity = entities[index2];
        
        gem1.Index = index2; gem2.Index = index1;
        
        var gPos = gem1.Pos; gem1.Pos = gem2.Pos; gem2.Pos = gPos;
        var cg = gem1.CellEntity; gem1.CellEntity = gem2.CellEntity; gem2.CellEntity = cg;
        
        gems[index1] = gem2; gems[index2] = gem1;
        entities[index1] = gem2Entity; entities[index2] = gem1Entity;
        
        entityManager.SetComponentData(gem1Entity, gem1);
        entityManager.SetComponentData(gem2Entity, gem2);

        var dist = math.distance(gem1.Pos, gem2.Pos);
        entityManager.AddComponentData(gem1Entity, new GemMoveData {
            PosVec = math.normalizesafe(new float3(gem2.Pos.x - gem1.Pos.x, 0.0f, gem2.Pos.y - gem1.Pos.y)) * dist, 
            PosSpeed = gemSpeed,
            Time = 1.0f / gemSpeed
        });
    }
    
    public static void SwapGems(GemData gem1, GemData gem2, NativeArray<Entity> entities, float gemSpeed, EntityManager entityManager) {
        int index1 = gem1.Index, index2 = gem2.Index;
        
        gem1.Index = index2; gem2.Index = index1;
        
        var gem1Entity = entities[index1]; var gem2Entity = entities[index2];
        var gPos = gem1.Pos; gem1.Pos = gem2.Pos; gem2.Pos = gPos;
        var cg = gem1.CellEntity; gem1.CellEntity = gem2.CellEntity; gem2.CellEntity = cg;
        
        entities[index1] = gem2Entity; entities[index2] = gem1Entity;
        
        entityManager.SetComponentData(gem1Entity, gem1);
        entityManager.SetComponentData(gem2Entity, gem2);

        var dist = math.distance(gem1.Pos, gem2.Pos);
        entityManager.AddComponentData(gem1Entity, new GemMoveData {
            PosVec = math.normalizesafe(new float3(gem2.Pos.x - gem1.Pos.x, 0.0f, gem2.Pos.y - gem1.Pos.y)) * dist, 
            PosSpeed = gemSpeed,
            Time = 1.0f / gemSpeed
        });
    }

}