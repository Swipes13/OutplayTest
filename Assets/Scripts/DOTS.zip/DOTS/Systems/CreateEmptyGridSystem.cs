using System;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Random = Unity.Mathematics.Random;

public class CreateEmptyGridSystem : ComponentSystem {
    protected override void OnUpdate() {
        Entities.WithAll<CreateGridTag>().ForEach((Entity entity, ref GridData gridData) => {
            for (var y = 0; y < gridData.Size.y; y++) {
                for (var x = 0; x < gridData.Size.x; x++) {
                    var index = GridView.GetIndex(x, y);
                    var cell = CreateCell(x, y, CellType.Empty);
                    var gem = CreateGem(x, y, GemType.Empty, cell);
                    GridView.Instance.cells[index] = cell;
                    GridView.Instance.gems[index] = gem;
                }
            }
            PostUpdateCommands.AddComponent<GridCheckMatchTag>(entity);
            PostUpdateCommands.AddComponent<GridStepMoveTag>(entity);
            PostUpdateCommands.RemoveComponent<CreateGridTag>(entity);
        });
    }

    public Entity CreateCell(int x, int y, CellType cellType) {
        var cell = EntityManager.Instantiate(CellCreator.CellPrefabEntity);
        EntityManager.SetComponentData(cell, new Translation { Value = new float3(x, -1, y) });
        EntityManager.AddComponentData(cell, new CellData {
            Pos = new int2(x, y),
            Index = GridView.GetIndex(x, y),
            Type = cellType,
            Selected = false
        });
        EntityManager.AddComponent<CellInvalidateRenderTag>(cell);
        return cell;
    } 
    public Entity CreateGem(int x, int y, GemType gt, Entity cellEntity) {
        var gem = EntityManager.Instantiate(CellCreator.GemPrefabEntity);
        EntityManager.SetComponentData(gem, new Translation { Value = new float3(x, -1f, y) });
        EntityManager.AddComponentData(gem, new GemData {
            Pos = new int2(x, y),
            Index = GridView.GetIndex(x, y),
            Type = gt,
            NeedToRemove = false,
            CellEntity = cellEntity
        });
        EntityManager.AddComponentData(gem, new Scale { Value = 0.75f });
        EntityManager.SetSharedComponentData(gem, CellCreator.GemRMs[(int)gt]);
        return gem;
    } 
}

