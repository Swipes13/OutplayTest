
using System.Collections.Generic;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;


public class GridCheckCanMoveSystem : ComponentSystem {
    protected override void OnUpdate() {
        Entities.WithAll<GridCheckCanMoveTag>().ForEach((Entity grid, ref GridData gridData) => {
            var gridSize = gridData.Size;
            var gems = new NativeArray<GemData>(gridSize.x * gridSize.y, Allocator.TempJob);
            Entities.WithAll<GemData>().ForEach((Entity entity, ref GemData gemData) => gems[gemData.Index] = gemData);
            
            var accum = new NativeArray<int>(4, Allocator.TempJob) { [0] = 0, [1] = 0, [2] = 0, [3] = 0 };
            var neigs = new NativeArray<int>(4, Allocator.TempJob) { [0] = -1, [1] = 1, [2] = -gridSize.x, [3] = gridSize.x };
            var neigsForSwap = new NativeArray<int>(2, Allocator.TempJob) { [0] = 1, [1] = gridSize.x };
            var possibleMoves = new NativeList<PossibleMove>(Allocator.TempJob);
            for (var x = 0; x < gridSize.x; x++) {
                for (var y = 0; y < gridSize.y; y++) {
                    var index = GridView.GetIndex(x, y);
                    
                    for (var i = 0; i < neigsForSwap.Length; i++) {
                        var sIndex = index + neigsForSwap[i];
                        
                        if (i == 0 && GridView.CheckInGridLineH(sIndex, index, gems.Length, gridSize.x) == false) continue;
                        if (i == 1 && GridView.CheckInGridLineV(sIndex, index, gems.Length, gridSize.x) == false) continue;
                    
                        SwapType(index, sIndex, gems);
                        
                        var current = gems[index];
                        var swapped = gems[sIndex];
                        
                        FillAccum(neigs, gems, gridSize, accum, index, current.Type);
                        if (accum[0] + accum[1] + 1 >= 3 || accum[2] + accum[3] + 1 >= 3) {
                            possibleMoves.Add(new PossibleMove {
                                Force = new int2(accum[0] + accum[1] + 1, accum[2] + accum[3] + 1),
                                SwapElements = new int2(index, sIndex),
                            });
                        }
                        accum[0] = accum[1] = accum[2] = accum[3] = 0;
                        
                        FillAccum(neigs, gems, gridSize, accum, sIndex, swapped.Type);
                        if (accum[0] + accum[1] + 1 >= 3 || accum[2] + accum[3] + 1 >= 3) {
                            possibleMoves.Add(new PossibleMove {
                                Force = new int2(accum[0] + accum[1] + 1, accum[2] + accum[3] + 1),
                                SwapElements = new int2(index, sIndex),
                            });
                        }
                        accum[0] = accum[1] = accum[2] = accum[3] = 0;
                        
                        SwapType(index, sIndex, gems);
                    }

                    accum[0] = accum[1] = accum[2] = accum[3] = 0;
                }
            }
            
            neigs.Dispose();
            neigsForSwap.Dispose();
            accum.Dispose();

            if (possibleMoves.Length == 0) {
                EntityManager.AddComponent<GridReshuffleTag>(grid);
                Debug.Log("!!NEED TO RESHUFFLE!!");
            } else {
                GridView.Instance.CurrentPossibleMoves = new List<PossibleMove>();
                for (var i = 0; i < possibleMoves.Length; i++) {
                    GridView.Instance.CurrentPossibleMoves.Add(possibleMoves[i]);
                }
            }

            EntityManager.RemoveComponent<GridCheckCanMoveTag>(grid);
            possibleMoves.Dispose();
            gems.Dispose();
        });
    }

    private void FillAccum(NativeArray<int> neigs, NativeArray<GemData> gems, int2 gridSize, NativeArray<int> accum, int index, GemType gemType) {
        for (var nn = 0; nn < neigs.Length; nn++) {
            var acc = 1;
            while (true) { 
                var gem2Index = index + neigs[nn] * acc;
                if (nn < 2 && GridView.CheckInGridLineH(gem2Index, index, gems.Length, gridSize.x) == false) break;
                if (nn >= 2 && GridView.CheckInGridLineV(gem2Index, index, gems.Length, gridSize.x) == false) break;
                if (gems[gem2Index].Type != gemType) break;
                acc += 1;
            } accum[nn] = acc - 1;
        }
    }
    
    private void SwapType(int i1, int i2, NativeArray<GemData> gems) {
        var s = gems[i1].Type;
        var g = gems[i1];
        g.Type = gems[i2].Type;
        gems[i1] = g;

        var gg = gems[i2];
        gg.Type = s;
        gems[i2] = gg;
    }
  
    private struct CheckPossibleMovesParallelJob : IJobParallelFor {
        [ReadOnly]
        public NativeArray<GemData> Gems;
        public NativeArray<PossibleMove> PossibleMoves;
        public int2 GridSize;

        
        public void Execute(int i) {
            var accum = new NativeArray<int>(4, Allocator.Temp) { [0] = 0, [1] = 0, [2] = 0, [3] = 0 };
            var neighbourOffsetArray = new NativeArray<int>(4, Allocator.Temp) { [0] = -1, [1] = 1, [2] = -GridSize.x, [3] = GridSize.x };
            var neighbourOffsetArrayForPM = new NativeArray<int>(2, Allocator.Temp) { [0] = 1, [1] = GridSize.x };
            
            var gem = Gems[i];

            if (gem.Type != GemType.Blocked && gem.Type != GemType.Empty) {
                var possibleMove = new PossibleMove();
                for (var pm = 0; pm < neighbourOffsetArrayForPM.Length; pm++) {
                    var pmIndex = gem.Index + neighbourOffsetArrayForPM[pm];
                    if (pm == 0 && CheckInGridLineH(pmIndex, i, Gems.Length, GridSize.x) == false) continue;
                    if (pm == 1 && CheckInGridLineV(pmIndex, i, Gems.Length, GridSize.x) == false) continue;
                    
                    var switchGem = Gems[pmIndex];
                    if (switchGem.Type == GemType.Blocked || switchGem.Type == GemType.Empty) continue;
                    
                    var sType = gem.Type;
                    gem.Type = switchGem.Type;
                    switchGem.Type = sType;
                    
                    for (int j = 0, acc = 1; j < neighbourOffsetArray.Length; j++) { 
                        while (true) { 
                            var gem2Index = i + neighbourOffsetArray[j] * acc;
                            if (j < 2 && CheckInGridLineH(gem2Index, i, Gems.Length, GridSize.x) == false) break;
                            if (j >= 2 && CheckInGridLineV(gem2Index, i, Gems.Length, GridSize.x) == false) break;
                            if (Gems[gem2Index].Type != gem.Type) break;
                            acc += 1;
                        } accum[j] = acc - 1;
                    }

                    // if (pm == 0) {
                    //     possibleMove.SwapElements1 = new int2(i, pmIndex);
                    //     possibleMove.Force1 = new int2(accum[0] + accum[1] + 1, accum[2] + accum[3] + 1);
                    //     possibleMove.WasMatch1 = accum[0] + accum[1] + 1 >= 3 || accum[2] + accum[3] + 1 >= 3;
                    // } else {
                    //     possibleMove.SwapElements3 = new int2(i, pmIndex);
                    //     possibleMove.Force3 = new int2(accum[0] + accum[1] + 1, accum[2] + accum[3] + 1);
                    //     possibleMove.WasMatch3 = accum[0] + accum[1] + 1 >= 3 || accum[2] + accum[3] + 1 >= 3;
                    // }

                    accum[0] = accum[1] = accum[2] = accum[3] = 0;

                    for (int j = 0, acc = 1; j < neighbourOffsetArray.Length; j++) { 
                        while (true) { 
                            var gem2Index = switchGem.Index + neighbourOffsetArray[j] * acc;
                            if (j < 2 && CheckInGridLineH(gem2Index, switchGem.Index, Gems.Length, GridSize.x) == false) break;
                            if (j >= 2 && CheckInGridLineV(gem2Index, switchGem.Index, Gems.Length, GridSize.x) == false) break;
                            if (Gems[gem2Index].Type != switchGem.Type) break;
                            acc += 1;
                        } accum[j] = acc - 1;
                    }
                    
                    // if (pm == 0) {
                    //     possibleMove.SwapElements2 = new int2(pmIndex, i);
                    //     possibleMove.Force2 = new int2(accum[0] + accum[1] + 1, accum[2] + accum[3] + 1);
                    //     possibleMove.WasMatch2 = accum[0] + accum[1] + 1 >= 3 || accum[2] + accum[3] + 1 >= 3;
                    // } else {
                    //     possibleMove.SwapElements4 = new int2(pmIndex, i);
                    //     possibleMove.Force4 = new int2(accum[0] + accum[1] + 1, accum[2] + accum[3] + 1);
                    //     possibleMove.WasMatch4 = accum[0] + accum[1] + 1 >= 3 || accum[2] + accum[3] + 1 >= 3;
                    // }

                    accum[0] = accum[1] = accum[2] = accum[3] = 0;
                }
                PossibleMoves[i] = possibleMove;
            }

            neighbourOffsetArrayForPM.Dispose();
            neighbourOffsetArray.Dispose();
            accum.Dispose();
        }
        
        private bool CheckInGridLineH(int checkIndex, int compareIndex, int count, int line) {
            return checkIndex >= 0 && checkIndex < count && checkIndex / line == compareIndex / line;
        }
        private bool CheckInGridLineV(int checkIndex, int compareIndex, int count, int line) {
            return checkIndex >= 0 && checkIndex < count && checkIndex % line == compareIndex % line;
        }
    }
    
}
