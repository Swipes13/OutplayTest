using System;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;
using Unity.Physics;
using Unity.Physics.Systems;
using Unity.Transforms;
using RaycastHit = Unity.Physics.RaycastHit;

public static class Converter {
    public static float3 ToFloat3(this Vector3 vec) {
        return new float3(vec.x, vec.y, vec.z);
    }
    public static Vector3 ToVector3(this float3 vec) {
        return new Vector3(vec.x, vec.y, vec.z);
    }
}

public class MouseInputSystem : ComponentSystem {
    private Vector3 mouseDownPos;
    private PhysicsWorld physicsWorld => World.DefaultGameObjectInjectionWorld.GetExistingSystem<BuildPhysicsWorld>().PhysicsWorld;

    protected override void OnUpdate() {
        Entities
            .WithNone<GridCheckMatchTag, GridCheckCanMoveTag, GridStepMoveTag>()
            .WithAll<GridData>()
            .ForEach((Entity grid)  => { // CHECK SWAP?
                MouseDownProcessor();
                MouseUpProcessor(GridView.Instance.gems);
            });
    }

    private void MouseDownProcessor() {
        if (!Input.GetMouseButton(0)) return; 
        var hit = GetHit(Input.mousePosition);
        var hitEntity = GetHitEntity(hit);
        if (EntityManager.HasComponent<GemData>(hitEntity) || EntityManager.HasComponent<CellData>(hitEntity)) {
            mouseDownEntity = hitEntity;
        }
    }
    private void MouseUpProcessor(NativeArray<Entity> gems) {
        if (!Input.GetMouseButtonUp(0)) return;
        if (mouseDownEntity == Entity.Null) return;
        var hit = GetHit(Input.mousePosition);
        var hitEntity = GetHitEntity(hit);

        if (hitEntity == Entity.Null) { 
            mouseDownEntity = Entity.Null;
            return;
        }

        var gemDataMD = ExtractGemData(mouseDownEntity, gems);
        var gemDataCurrent = ExtractGemData(hitEntity, gems);

        if (!gemDataMD.HasValue || !gemDataCurrent.HasValue && gemDataMD.Value.Index != gemDataCurrent.Value.Index) {
            mouseDownEntity = Entity.Null;
            return;
        }
        
        var gd = gemDataMD.Value;
        if (gd.Type == GemType.Blocked || gd.Type == GemType.Empty) {
            mouseDownEntity = Entity.Null;
            return;
        }

        var hitGem = gems[gd.Index];

        if (selectedGem == Entity.Null) {
            selectedGem = hitGem;
            ChangeSelection(selectedGem, true);
        } else if (selectedGem == hitGem) {
            ChangeSelection(selectedGem, false);
            selectedGem = Entity.Null;
        } else {
            var gs = GridView.Instance.GridSize;
            var g1 = EntityManager.GetComponentData<GemData>(selectedGem);
            var g2 = EntityManager.GetComponentData<GemData>(hitGem);
            var h = GridView.CheckInGridLineH(g1.Index, g2.Index, gs.x * gs.y, gs.x) && math.abs(g1.Index - g2.Index) == 1;
            var v = GridView.CheckInGridLineV(g1.Index, g2.Index, gs.x * gs.y, gs.x) && math.abs(g1.Index - g2.Index) == gs.x;
            if (h || v) {
                int2 m1 = new int2(g1.Index, g2.Index), m2 = new int2(g2.Index, g1.Index);
                var pm = GridView.Instance.CurrentPossibleMoves;
                var exists = pm.Exists(m => m.SwapElements.Equals(m1)) || pm.Exists(m => m.SwapElements.Equals(m2));
                
                const float gemSpeed = 5.0f;
                var dist = math.distance(g2.Pos, g1.Pos);
                var time = dist / gemSpeed;

                if (exists) {
                    GridStepMoveSystem.SwapGems(g1, g2, GridView.Instance.gems, gemSpeed, EntityManager);
                    PostUpdateCommands.AddComponent<GridCheckMatchTag>(GridView.Instance.GridEntity);
                    ChangeSelection(selectedGem, false);
                } else {
                    EntityManager.AddComponentData(selectedGem, new GemSwapData {
                        FullTime = time, Time = time, 
                        PosTo = new float3(g2.Pos.x, -1.0f, g2.Pos.y),
                        PosFrom = new float3(g1.Pos.x, -1.0f, g1.Pos.y),
                        Up = false
                    });
                    EntityManager.AddComponentData(hitGem, new GemSwapData {
                        FullTime = time, Time = time, 
                        PosTo = new float3(g1.Pos.x, -1.0f, g1.Pos.y), 
                        PosFrom = new float3(g2.Pos.x, -1.0f, g2.Pos.y), 
                        Up = true
                    });
                    ChangeSelection(hitGem, true);
                }
                selectedGem = Entity.Null;
            } else {
                ChangeSelection(selectedGem, false);
                selectedGem = hitGem;
                ChangeSelection(selectedGem, true);
            }
        }
    }

    private GemData? ExtractGemData(Entity cellOrGem, NativeArray<Entity> gems) {
        var gemEntity = Entity.Null;
        if (EntityManager.HasComponent<CellData>(cellOrGem)) {
            gemEntity = gems[EntityManager.GetComponentData<CellData>(cellOrGem).Index];
        } else if (EntityManager.HasComponent<GemData>(cellOrGem)) {
            gemEntity = cellOrGem;
        }

        if (gemEntity != Entity.Null) {
            return EntityManager.GetComponentData<GemData>(gemEntity);
        } 
        return null;
        
    }

    private void ChangeSelection(Entity entity, bool selected) {
        var gemData = EntityManager.GetComponentData<GemData>(entity);
        var cellData = EntityManager.GetComponentData<CellData>(gemData.CellEntity);
        cellData.Selected = selected;
        
        if (selected) EntityManager.AddComponent<GemSelectedTag>(entity);
        else EntityManager.RemoveComponent<GemSelectedTag>(entity);

        EntityManager.SetComponentData(gemData.CellEntity, cellData);
        EntityManager.AddComponent<CellInvalidateRenderTag>(gemData.CellEntity);
    }

    private Entity mouseDownEntity = Entity.Null;
    private Entity selectedGem = Entity.Null;
    
    public static uint CollidesWith() {
        return 1u << Gui.GemsLayer | 1u << Gui.CellsLayer;
    }
    
    private Entity GetHitEntity(RaycastHit? hit) {
        return hit.HasValue ? physicsWorld.Bodies[hit.Value.RigidBodyIndex].Entity : Entity.Null;
    }
    private RaycastHit? GetHit(Vector3 mousePosition) {
        const float rayDist = 100.0f; // TODO
        var ray = Gui.Instance.Camera.ScreenPointToRay(mousePosition); 
        var collisionWorld = physicsWorld.CollisionWorld;

        var wasHit = collisionWorld.CastRay(new RaycastInput {
            Start = ray.origin,
            End = ray.GetPoint(rayDist),
            Filter = new CollisionFilter {
                BelongsTo = 0xffffffff,
                CollidesWith = CollidesWith(),
                GroupIndex = 0
            }
        }, out var hit);

        return wasHit ? hit : (RaycastHit?) null;
    }
}

public class PointAndClick : MonoBehaviour {
    private static Entity RayCast(float3 from, float3 to) {
        var physicsWorld = World.DefaultGameObjectInjectionWorld.GetExistingSystem<BuildPhysicsWorld>().PhysicsWorld;
        var collisionWorld = physicsWorld.CollisionWorld;

        return collisionWorld.CastRay(new RaycastInput {
            Start = from,
            End = to,
            Filter = new CollisionFilter {
                BelongsTo = 0xffffffff,
                CollidesWith = MouseInputSystem.CollidesWith(),
                GroupIndex = 0
            }
        }, out var hit) ? physicsWorld.Bodies[hit.RigidBodyIndex].Entity : Entity.Null;
    }
}
