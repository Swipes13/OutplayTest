﻿using System;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Random = Unity.Mathematics.Random;

public class GridView : MonoBehaviour {
    public static GridView Instance { get; private set; }
    public int2 GridSize; // (100, 100) TEST -> 65ms. CheckMatchJob 8.6 ms 
    public List<PossibleMove> CurrentPossibleMoves = new List<PossibleMove>();
    public Random Random;
    public Entity GridEntity;
    public NativeArray<Entity> gems;
    public NativeArray<Entity> cells;

    [HideInInspector] private Level level;

    private void Awake() {
        Instance = this;
        Random = new Random(42);
        var json = Resources.Load("Levels/Test").ToString();
        level = Level.FromJson(json);
        GridSize = level.s;
        CurrentPossibleMoves = new List<PossibleMove>();
    }

    public static int GetIndex(int2 pos) {
        return GetIndex(pos.x, pos.y);
    }
    public static int GetIndex(int x, int y) {
        return x + y * Instance.GridSize.x;
    }
    public static GemType GetRandomGemType() {
        var maxCount = 3; // TODO: do
        return (GemType)(2 + Instance.Random.NextInt(maxCount));
    }
    private void Start() {
        // GridSize = new int2(50, 50);

        var em = World.DefaultGameObjectInjectionWorld.EntityManager;
        GridEntity = em.CreateEntity();
        gems = new NativeArray<Entity>(GridSize.x * GridSize.y, Allocator.Persistent);
        cells = new NativeArray<Entity>(GridSize.x * GridSize.y, Allocator.Persistent);
        em.AddComponentData(GridEntity, new GridData { Size = GridSize });
        // em.AddComponent<CreateGridTag>(GridEntity);
        for (var y = 0; y < GridSize.y; y++) {
            for (var x = 0; x < GridSize.x; x++) {
                var index = GridView.GetIndex(x, y);
                var cell = CreateCell(em, level.c[index]);
                var gem = CreateGem(em, level.g[index], cell);
                cells[index] = cell;
                gems[index] = gem;
            }
        }
        em.AddComponent<GridCheckMatchTag>(GridEntity);
        em.AddComponent<GridStepMoveTag>(GridEntity);
        em.RemoveComponent<CreateGridTag>(GridEntity);
    }
    private Entity CreateCell(EntityManager em, CellData cd) {
        var cell = em.Instantiate(CellCreator.CellPrefabEntity);
        em.SetComponentData(cell, new Translation { Value = new float3(cd.Pos.x, -1, cd.Pos.y) });
        em.AddComponentData(cell, cd);
        if (cd.Type != CellType.Empty) {
            em.SetSharedComponentData(cell, CellCreator.CellRMs[(int) cd.Type]);
        }
        return cell;
    } 
    private Entity CreateGem(EntityManager em, GemData gd, Entity cellEntity) {
        gd.CellEntity = cellEntity;
        
        var gem = em.Instantiate(CellCreator.GemPrefabEntity);
        em.SetComponentData(gem, new Translation { Value = new float3(gd.Pos.x, -1f, gd.Pos.y) });
        em.AddComponentData(gem, gd);
        em.AddComponentData(gem, new Scale { Value = 0.75f });
        em.SetSharedComponentData(gem, CellCreator.GemRMs[(int)gd.Type]);
        return gem;
    } 

    private void OnDestroy() {
        gems.Dispose();
        cells.Dispose();
    }

    public static bool CheckInGridLineH(int checkI, int compareI, int all, int line) {
        return checkI >= 0 && checkI < all && checkI / line == compareI / line;
    }
    public static bool CheckInGridLineV(int checkI, int compareI, int all, int line) {
        return checkI >= 0 && checkI < all && checkI % line == compareI % line;
    }
    
    public static bool CheckInGridLineH(int checkI, int compareI) {
        return checkI >= 0 && checkI < Instance.gems.Length && checkI / Instance.GridSize.x == compareI / Instance.GridSize.x;
    }
    public static bool CheckInGridLineV(int checkI, int compareI) {
        return checkI >= 0 && checkI < Instance.gems.Length && checkI % Instance.GridSize.x == compareI % Instance.GridSize.x;
    }
}
